import {Container, RunSet} from '../models/project';
import {LayoutContentType, LayoutMaster, LayoutRule, ShapeAlignment, ShapeType, ShapeWidthType} from '../graph/layout-rule';

export class ContainerLayoutTemplates {

  public static layoutDeployment(deployment: RunSet): LayoutMaster {

    return new LayoutMaster(LayoutContentType.deploymentCollection, ShapeWidthType.full, ShapeAlignment.center, ContainerLayoutTemplates.addRemainingObjects(null, deployment.deployments));
  }

  public static layoutContainers(containers: Container[]): LayoutMaster {

    let deploymentType: LayoutContentType;

    containers.forEach((c) => {
      if (c.type == 'apimg') {
        if (deploymentType == LayoutContentType.msr) {
          deploymentType = LayoutContentType.msrWithApiEnforcement;
        } else {
          deploymentType = LayoutContentType.apiEnforcement;
        }
      } else if (c.type == 'msr') {
        if (deploymentType == LayoutContentType.apiEnforcement) {
          deploymentType = LayoutContentType.msrWithApiEnforcement;
        } else {
          deploymentType = LayoutContentType.msr;
        }
      } else if (deploymentType == LayoutContentType.other && c.type == 'apigw' || c.type == 'apipr') {
        deploymentType = LayoutContentType.apiMgmt;
      } else if (deploymentType == LayoutContentType.other && c.type == 'storage') {
        deploymentType = LayoutContentType.storage
      }
    });

    if (deploymentType === LayoutContentType.msr || deploymentType === LayoutContentType.msrWithApiEnforcement) {
      return ContainerLayoutTemplates.layoutForMicroServiceLayer(containers, deploymentType);
    } else if (deploymentType == LayoutContentType.apiMgmt) {
      return new LayoutMaster(deploymentType, ShapeWidthType.full, ShapeAlignment.center, ContainerLayoutTemplates.addRemainingObjects([], containers));
    } else if (deploymentType == LayoutContentType.storage) {
      return new LayoutMaster(deploymentType, ShapeWidthType.dynamic, ShapeAlignment.center, ContainerLayoutTemplates.addRemainingObjects([], containers));

    } else {
      // other
      return new LayoutMaster(LayoutContentType.other, ShapeWidthType.dynamic, ShapeAlignment.center, ContainerLayoutTemplates.addRemainingObjects([], containers));
    }
  }

  public static layoutForMicroServiceLayer(containers: Container[], type: LayoutContentType): LayoutMaster {

    let rules: LayoutRule[] = [];

    if (type == LayoutContentType.msrWithApiEnforcement) {

      // make sure micro gateway is first to render

      var mgContainers: Container[] = ContainerLayoutTemplates.containersForType('apimg', containers);

      for (let i = 0; i < mgContainers.length; i++) {
        rules.push(new LayoutRule(mgContainers[i].id, mgContainers[i].name, ShapeType.ellipse, i == 0, ShapeAlignment.center))
      }
    }

    var msrContainers: Container[] = ContainerLayoutTemplates.containersForType('msr', containers);

    for(let i = 0; i < msrContainers.length; i++) {
      rules.push(new LayoutRule(msrContainers[i].id, msrContainers[i].name, ShapeType.rect, i == 0, ShapeAlignment.center))
    }

    return new LayoutMaster(type, ShapeWidthType.half, ShapeAlignment.center, ContainerLayoutTemplates.addRemainingObjects(rules, containers));
  }

  public static addRemainingObjects(rules: LayoutRule[], objects: any[]): LayoutRule[] {

    if (rules == null) {
      rules = [];
    }

    objects.forEach((c) => {
      if (ContainerLayoutTemplates.objectNotIncluded(rules, c)) {
        rules.push(new LayoutRule(c.id, c.name, ShapeType.rect, c == objects[0], ShapeAlignment.center));
      }
    });

    return rules;
  }

  public static objectNotIncluded(rules: LayoutRule[], container: any): boolean {

    let found: boolean = false;

    for (let i = 0; i < rules.length; i++) {
      if (rules[i].name == container.name) {
        found = true;
        break;
      }
    }
    return !found;
  }

  public static containersForType(type: string, containers: Container[]): Container[] {

    var out: Container[] = [];

    containers.forEach((c) => {
      if (c.type == type) {
        out.push(c);
      }
    });

    return out;
  }
}

