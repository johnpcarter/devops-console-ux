import {
  Component, ChangeDetectorRef, ViewChild,
  OnInit, OnDestroy
} from '@angular/core';

import {Router, ActivatedRoute} from '@angular/router';
import {FormBuilder, FormGroup, FormControl} from '@angular/forms';
import {SelectionModel} from '@angular/cdk/collections';


import {MatDialog} from '@angular/material/dialog';
import {MatSnackBar} from '@angular/material/snack-bar';

import {Settings} from '../settings';

import {DockerImage} from '../models/docker-image';
import {ResourceService} from '../services/resources.service';

import {DockerService} from '../services/docker.service';
import {
  RunSet, Builder, DeploymentSet, Deployment, DockerBuild,
  Arg, Container, BuildCommand
} from '../models/project';
import {APIDefinition} from '../models/wm-package-info';
import {ConfigurationService} from '../services/configuration.service';
import {EditContainerComponent} from './staging.component';
import {ContainerTemplates} from '../support/container.templates';
import {BuildExeComponent} from './build-exe.component';

@Component({
  selector: 'runtime-deploy',
  templateUrl: '../templates/runtime-deploy.html',
  styleUrls: ['../templates/runtime-deploy.css']
})

export class RuntimeDeployComponent implements OnInit {

  public hints: Map<string, string> = new Map([['EXTERNAL', 'Assume API Gateway hosted elsewhere']]);

  public setupOkay: boolean = false;
  public isLinearStepper: boolean = true;

  public deployTypeFormGroup: FormGroup;
  public apiFormGroup: FormGroup;
  public containerFormGroup: FormGroup;
  public finaliseFormGroup: FormGroup;
  public microserviceFormGroup: FormGroup;

  public runSets: string[] = [];
  public currentRunSet: RunSet;
  public currentRunSetInitialised: boolean;

  public builds: string[];

  public baseImages: DockerImage[] = [];
  public customImages: DockerImage[] = [];
  public allImages: DockerImage[] = [];

  public buildListCtrl: FormControl;
  public showKubernetesCtrl: FormControl;
  public runSetCtrl: FormControl;

  public useMicrogatewayCtrl: FormControl;
  public microgatewayTypeCtrl: FormControl;
  public usePortalCtrl: FormControl;
  public includeTestsCtrl: FormControl;
  public uploadAPICtrl: FormControl;
  public runTypeCtrl: FormControl;

  public propsCtrl: FormControl;
  public microServicePropsCtrl: FormControl;
  public envPropsCtrl: FormControl;
  public envHostDirCtrl: FormControl;
  public envServiceDirCtrl: FormControl;
  public envPersistLogsCtrl: FormControl;
  public envPersistOtherLogsCtrl: FormControl;
  public envConfigCtrl: FormControl;
  public envPackagesCtrl: FormControl;
  public downloadCtrl: FormControl;

  public configTemplatesList: string[];

  public apiDisplayedColumns: string[] = ['select', 'name', 'description'];
  public selectedAPIs: SelectionModel<APIDefinition> = new SelectionModel<APIDefinition>(true, []);
  public apis: APIDefinition[] = [];
  public selectedImages: string[];
  public running: boolean = false;
  public starting: boolean = false;
  public isTemplate: boolean = false;

  public packages: string[] = [];

  public propertyFiles: string[] = [];

  private addedApisControls: boolean = false;
  private _ignoreValuesChange: boolean = false;

  private _dockerHost: string;

  private _id: string = null;

  @ViewChild('downloadLink')
  private _downloadLink;

  public constructor(private _router: Router, private _inboundRouter: ActivatedRoute, private _snackBar: MatSnackBar, private _settings: Settings, private _dockerService: DockerService, private _dialog: MatDialog,
                     private _formBuilder: FormBuilder, private _resources: ResourceService, private _configService: ConfigurationService, private _containerTemplates: ContainerTemplates) {

    let sub = this._inboundRouter.params.subscribe(params => {

      this._id = params['id'];

    });

    this.runSets = [];
    this._configService.runSets().subscribe((p) => {
      this.runSets = p;

      if (this._id) {
        this.setTemplate(this._id);
      }
    });

    this.builds = ['external'];
    this._configService.builds().subscribe((builds) => {

      builds.forEach((b) => {
        this.builds.push(b);
      });
    });

    this._settings.values().subscribe((v) => {
      this._dockerHost = v.dockerHost;
      this._dockerService.setup(v);

      this.baseImages = [];
      this._dockerService.sagImages(false).subscribe((d) => {

        this.baseImages = d;

        this.baseImages.unshift(new DockerImage('EXTERNAL'));

        this._dockerService.customImages(false).subscribe((images) => {

          this.customImages = images;
          this.setupOkay = true;
        });

        this._dockerService.baseImages(false).subscribe((r) => {
          this.allImages = r;
        });
      });

      this.propertyFiles = [];

      this._resources.resourcesForType('properties').subscribe((p) => {

        this.propertyFiles = [];
        p.forEach((f) => {
          this.propertyFiles.push(f.name);
        });
      });

      this._settings.setCurrentPage('run', this._id);
    });

    this.currentRunSet = new RunSet();
    this.currentRunSet.name = '';

    this.buildListCtrl = new FormControl();
    this.showKubernetesCtrl = new FormControl();
    this.runSetCtrl = new FormControl();

    this.useMicrogatewayCtrl = new FormControl();
    this.microgatewayTypeCtrl = new FormControl('env');
    this.runTypeCtrl = new FormControl('docker');
    this.usePortalCtrl = new FormControl();
    this.includeTestsCtrl = new FormControl();
    this.uploadAPICtrl = new FormControl();

    this.propsCtrl = new FormControl();
    this.microServicePropsCtrl = new FormControl('default');
    this.envHostDirCtrl = new FormControl();
    this.envServiceDirCtrl = new FormControl();
    this.envPropsCtrl = new FormControl();
    this.envPersistLogsCtrl = new FormControl('false');
    this.envPersistOtherLogsCtrl = new FormControl('NONE');
    this.envConfigCtrl = new FormControl('false');
    this.envPackagesCtrl = new FormControl('false');
    this.downloadCtrl = new FormControl(true);

    this.deployTypeFormGroup = this._formBuilder.group({
      buildListCtrl: this.buildListCtrl,
      showKubernetesCtrl: this.showKubernetesCtrl,
      runSetCtrl: this.runSetCtrl
    });

    this.apiFormGroup = this._formBuilder.group({});

    this.microserviceFormGroup = this._formBuilder.group({
      propsCtrl: this.propsCtrl,
      microServicePropsCtrl: this.microServicePropsCtrl,
      envHostDirCtrl: this.envHostDirCtrl,
      envPropsCtrl: this.envPropsCtrl,
      envPersistLogsCtrl: this.envPersistLogsCtrl,
      envServiceDirCtrl: this.envServiceDirCtrl,
      envPersistOtherLogsCtrl: this.envPersistOtherLogsCtrl,
      envConfigCtrl: this.envConfigCtrl,
      envPackagesCtrl: this.envPackagesCtrl
    });

    this.containerFormGroup = this._formBuilder.group({});

    this.finaliseFormGroup = this._formBuilder.group({
      includeTestsCtrl: this.includeTestsCtrl,
      uploadAPICtrl: this.uploadAPICtrl,
      downloadCtrl: this.downloadCtrl,
      runTypeCtrl: this.runTypeCtrl
    });
  }

  public ngOnInit() {

    this.deployTypeFormGroup.valueChanges.subscribe((d) => {

      if (this._ignoreValuesChange) {
        return;
      }

      if (this.buildListCtrl.dirty) {
        this.setBuildForRunSet(this.buildListCtrl.value);
        this.buildListCtrl.markAsPristine();
      } else if (this.showKubernetesCtrl.dirty) {
        this.currentRunSet.useKubernetes = this.showKubernetesCtrl.value;
        this.runTypeCtrl.setValue(this.currentRunSet.useKubernetes ? 'k8s' : 'docker');
        ContainerTemplates.setDefaultsForK8s(this.currentRunSet);
        this._save();
        this.showKubernetesCtrl.markAsPristine();

        this.refreshContainerPortsList();

      } else if (this.runSetCtrl.dirty && this.runSetCtrl.value.length > 0 && this.runSetCtrl.value != this.currentRunSet.name) {
        this.setTemplate(this.runSetCtrl.value);
        this.runSetCtrl.markAsPristine();
      }
    });

    this.microserviceFormGroup.valueChanges.subscribe((d) => {

      if (this._ignoreValuesChange) {
        return;
      }

      if (this.propsCtrl.dirty) {

        this.setPropertiesFile(this.propsCtrl.value);
        this._save();
        this.propsCtrl.markAsPristine();
      }

      this.updateMicroServiceContainerEnvProperties();

    });

    this.apiFormGroup.valueChanges.subscribe((d) => {

      if (this._ignoreValuesChange) {
        return;
      }

      if (this.useMicrogatewayCtrl.dirty && !this.useMicrogatewayCtrl.value) {
        this.removeMicrogatewayContainer();
        this.useMicrogatewayCtrl.markAsPristine();

        this._save();

      } else if (this.usePortalCtrl.dirty && !this.usePortalCtrl.value) {

        this.useMicrogatewayCtrl.markAsPristine();

        this._ignoreValuesChange = true;
        this.removePortalContainer();
        this._ignoreValuesChange = false;

        this._save();
      }
    });
  }

  public buildOptionStyle(value: string): any {

    if (this.buildListCtrl.value && this.buildListCtrl.value.length > 0 &&  this.buildListCtrl.value[0] == 'external' && value != 'external') {
      return {"color": "gray"};
    } else {
      return {};
    }
  }

  public haveMSR(): boolean {
    return this.currentRunSet.containerInDeploymentFor('msr') != null;
  }

  public labelForBuild() {

    if (this.currentRunSet.builds && this.currentRunSet.builds.length > 0 && this.currentRunSet.builds[0].name) {
      return 'Run: ' + this.currentRunSet.builds[0].name;
    } else {
      return 'Select Build Template';
    }
  }

  public haveBuildTemplates() {

    return this.builds && this.builds.length > 0;
  }

  public goBuildPage() {

    this._router.navigate(['/image']);
  }

  public tabChanged(event: any) {

    if (this.isLinearStepper && event.previouslySelectedIndex == 2) {
      this.currentRunSetInitialised = true;
    }
  }

  /** Whether the number of selected elements matches the total number of rows. */
  public isAllAPIsSelected() {
    const numSelected = this.selectedAPIs.selected.length;
    const numRows = this.apis.length;

    return numSelected === numRows;
  }

  public selectAPIRow(row) {

    this.selectedAPIs.toggle(row);

    this.apiSelectionDidChange();
  }

  /** Selects all rows if they are not all selected; otherwise clear selectedDependencies. */
  public masterAPIToggle() {

    this.isAllAPIsSelected() ?
      this.selectedAPIs.clear() :
      this.apis.forEach(row => this.selectedAPIs.select(row));

    this.apiSelectionDidChange();
  }

  private apiSelectionDidChange() {

    if (this.selectedAPIs.selected.length > 0) {

      if (!this.addedApisControls) {
        this.enableAPIControls();
      }
    } else {

      if (this.addedApisControls) {
        this.disableAPIControls();
      }
    }

    this.currentRunSet.deployments.forEach((d) => {

      d.apis = [];

      this.selectedAPIs.selected.forEach((s) => {

        if (s.deployment == d.name) {
          d.apis.push(s);
        }
      });
    });

    this._save();
  }

  public haveSelectedAPIGateway(): boolean {

    let apiLayer: Deployment = this.serviceFor('API Management');

    return apiLayer && this.containerInServiceForType(apiLayer, 'apigw') != null;
  }

  public imageForCurrentAPIGateway(): DockerImage {

    return this.imageForContainerType('apigw');
  }

  public apiGatwaySelected(image: DockerImage) {

    this.setAPIContainer(image);
    this._save();
  }

  public currentAPIPortal(): DockerImage {

    if (this.usePortalCtrl.value) {
      return this.imageForContainerType('apipr');
    } else {
      return null;
    }
  }

  public apiPortalSelected(image: DockerImage) {

    this.setPortalContainer(image);
    this._save();
  }

  public currentMicroGateway(): DockerImage {

    if (this.useMicrogatewayCtrl.value) {
      return this.imageForContainerType('apimg');
    } else {
      return null;
    }
  }

  public microGatewaySelected(image: DockerImage) {

    this.setMicrogatewayContainer(image, this.microgatewayTypeCtrl.value);
    this._save();
  }

  public microGatewayTypeChanged() {

    this.setMicrogatewayContainer(this.currentMicroGateway(), this.microgatewayTypeCtrl.value);
    this._save();
  }

  public containerConfigDidChange(container: Container) {

    if (container && container.type == 'MicroService Runtime') {

      let svc: Deployment = this.currentRunSet.deploymentForContainer(container);

      if (svc) {
        this.setAPIEndPointForContainer(svc, container);
      }

      this.setAvailableAPIs();
    }

    this._save();
  }

  public isExistingTemplate(): boolean {

    return this.currentRunSet && this.indexOfTemplate(this.currentRunSet.name) != -1;
  }

  public addTemplate(event) {

    this.currentRunSet.name = this.runSetCtrl.value;

    this._configService.uploadRunSet(this.currentRunSet).subscribe((success) => {

      this.isTemplate = true;
      this.runSets.push(this.currentRunSet.name);
    });
  }

  public deleteTemplate(event) {

    var name = this.currentRunSet.name;

    this._configService.deleteRunSet(name).subscribe((success) => {

      this.runSets.splice(this.indexOfTemplate(name), 1);
      this.runSetCtrl.setValue('', {onlySelf: true, emitEvent: false});
      this.currentRunSet = new RunSet();
      this.isTemplate = false;
    });
  }

  public deployments(): Deployment[] {

    if (this.currentRunSet && this.currentRunSet.deployments) {
      return this.currentRunSet.deployments;
    } else {
      return [];
    }
  }

  public targetTag(build: Builder) {
    return build.targetImage.tag();
  }

  public labelForGoButton(): string {

    if (this.downloadCtrl.value) {
      return this.runTypeCtrl.value == 'docker' ? 'Run' : 'Deploy to K8s';
    } else {
      return this.runTypeCtrl.value == 'docker' ? 'Download' : 'Download K8s Definition';
    }
  }

  public go() {

    if (this.downloadCtrl.value) {
      this.run();
    } else {
      this.download();
    }
  }

  public run() {

    this.starting = true;

    // build on server

    let dialogRef = this._dialog.open(BuildExeComponent, {
      width: '80%',
      height: '80%',
      data: {
        run: this.currentRunSet,
        runK8s: this.runTypeCtrl.value == 'k8s',
        includeTests: this.includeTestsCtrl.value,
        uploadAPIs: this.uploadAPICtrl.value,
        environment: this._settings.currentEnvironment == 'Default' ? null : this._settings.currentEnvironment
      },
    });

    dialogRef.afterClosed().subscribe(result => {
      this._save();
      this.starting = false;

      if (result) {
        this._settings.currentRuntime = this.currentRunSet.name;

        let ref: RuntimeDeployComponent = this;
        setTimeout(() => {

          ref.starting = false;

          if (result) {
            ref.running = true;
            ref._router.navigate(['/deploy']);
          }
        }, 250);
      }
    });
  }

  public download() {

    this.starting = true;

    this._dockerService.run(this.currentRunSet, this.runTypeCtrl.value == 'k8s', this.includeTestsCtrl.value || false, true, this.uploadAPICtrl.value, this._settings.currentEnvironment == 'Default' ? null : this._settings.currentEnvironment).subscribe((file) => {

      if (file.type === null) {
        this._snackBar.open('Deployment generation failed', 'Dismiss', {duration: 5000});
      } else {
        this.starting = false;

        let url = window.URL.createObjectURL(file);
        const link = this._downloadLink.nativeElement;
        link.href = url;

        if (file.type == 'application/zip') {
          link.download = 'deploy-' + this.currentRunSet.name + '.zip';
        } else { //if (file.type == "application/yaml") {
          if (this.runTypeCtrl.value === 'k8s') {
            link.download = 'k8s-create.' + this.currentRunSet.name + '.yaml';
          } else {
            link.download = 'docker-compose.' + this.currentRunSet.name + '.yaml';
          }
        }

        link.click();

        window.URL.revokeObjectURL(url);
      }
    });
  }

  public stop() {

    this.starting = true;

    this._dockerService.stop(this.currentRunSet).subscribe((status) => {

      this.starting = false;

      if (status) {
        this.running = false;
      } else {
        window.alert('Oops, I\'m afraid I cannot allow you to do that Dave');
      }
    });

  }

  private _save() {

    if (!this.isTemplate) {
      return;
    }

    console.log('saving run template');

    this._configService.uploadRunSet(this.currentRunSet).subscribe((success) => {

      var found: boolean = false;

      if (this.runSets) {
        for (var i = 0; i < this.runSets.length; i++) {
          if (this.runSets[i] == this.currentRunSet.name) {
            found = true;
            break;
          }
        }
      }

      if (!found) {
        this.runSets.push(this.currentRunSet.name);
      }
    });
  }

  private setBuildForRunSet(names: string[]) {

    this.selectedImages = [];
    this.currentRunSet.builds = [];
    this.apis = [];
    this.packages = [];
    this.selectedImages = null;

    if (names[0] == 'external') {
      this.buildListCtrl.setValue(['external'], {emitEvent: false});

    } else {
      names.forEach((n) => {
        this._setBuildForRunSet(n);
      });

      let removeList: number[] = [];
      let i: number = 0;
      this.currentRunSet.deployments.forEach((d) => {
        if (names.indexOf(d.name) == -1) {
          // remove if it contains a sub-container of type MSR.
          d.containers.forEach((c) => {
            if (c.name.toLowerCase() == d.name.toLowerCase() && c.type == 'msr') {
              removeList.push(i);
            }
          });

          i+= 1;
        }
      });

      removeList.forEach((i) => {
        this.currentRunSet.deployments.splice(i, 1);
      })
    }
  }

  private _setBuildForRunSet(name: string) {

    this._configService.build(name).subscribe((b) => {

      this.currentRunSet.builds.push(b);

      let found: DockerImage = this.imageFor(b.targetImage.name());

      if (found) {
        b.targetImage.setVersion(found.version());
      }

      this.setAvailableAPIs();
      this.setContainerForBuild(b);

      if (this.useMicrogatewayCtrl.value) {
        this.setMicrogatewayContainer(this.currentMicroGateway(), this.microgatewayTypeCtrl.value);
      }

      this._save();
    });
  }

  private setTemplate(name: string): boolean {

    if (this.indexOfTemplate(name) != -1) {

      this.currentRunSet = new RunSet();

      this._configService.runSet(name).subscribe((runSet) => {

        this.isLinearStepper = false;
        this.currentRunSetInitialised = true;
        this.isTemplate = true;
        this.currentRunSet = runSet;
        this._ignoreValuesChange = true;
        this.runSetCtrl.setValue(name);
        this._ignoreValuesChange = false;
        this.updateForms();
        this.refresh();
      });

      return true;

    } else {
      this.isTemplate = false;
      this.currentRunSet.name = this.runSetCtrl.value;
      return false;
    }
  }

  private setPropertiesFile(props: string) {

    this.currentRunSet.deployments.forEach((d) => {
      d.containers.forEach((c) => {
        if (c.type == 'MicroService Runtime') {
          this._setPropertiesFile(c, props);
        }
      });
    });
  }

  private _setPropertiesFile(container: Container, props: string) {

    let file: BuildCommand;

    if (container.build) {
      file = container.fileForType('properties');
    }

    let propsName: string;

    if (this.currentRunSet.name) {
      propsName = this.currentRunSet.name.toLowerCase().replace(/\s/g, '-');
    } else {
      propsName = 'run';
    }

    if (!file && props) {

      // add if not already in list

      file = new BuildCommand();
      file.commandType = 'file';
      file.buildTarget = 'build';
      file.fileType = 'properties';
      file.description = 'Micro Deployment Properties Field';

      //ensures that the build-components view gets updated

      if (!container.build) {
        container.build = new DockerBuild(file);
      } else {
        container.build.buildCommands.push(file);
      }

      container.build.buildCommands = Object.assign([], container.build.buildCommands);

    } else if (file && !props) {

      // remove

      container.build.buildCommands.splice(container.build.buildCommands.indexOf(file), 1);
    }

    if (props) {

      file.source = props.replace(/\s/g, '-');
      file.target = '/opt/softwareag/IntegrationServer/' + propsName + '.properties';

      this._ignoreValuesChange = true;
      this.envPropsCtrl.setValue(file.target);
      this.updateEnvPropsFile(container);
      this._ignoreValuesChange = false;
    }
  }

  private refresh() {

    let refreshedBuilds: Builder[] = [];

    this.currentRunSet.builds.forEach((b) => {
      this._configService.build(b.name).subscribe((build) => {

        refreshedBuilds.push(build);

        let refreshedDeployments: DeploymentSet[] = [];
        build.deployments.forEach((d) => {

          this._configService.deploymentSet(d.name).subscribe((deploymentset) => {

            refreshedDeployments.push(deploymentset);
            build.deployments = refreshedDeployments;
            this.replaceBuildsList(refreshedBuilds);
          });
        });
      });
    });
  }

  private replaceBuildsList(builds: Builder[]) {

    if (builds.length > 0) {

      this.currentRunSet.builds = builds;
      this.updateForms();
      this._save();
    } else {

      // not ready yet

      let ref: RuntimeDeployComponent = this;
      setTimeout(() => {
        ref.replaceBuildsList(builds);
      }, 500);
    }
  };

  private updateForms() {

    // update main build and runtime container version to latest

    let names: string[] = [];
    this.currentRunSet.builds.forEach((b) => {

      names.push(b.name);

      if (b.targetImage) {
        let latest: DockerImage = b.targetImage.id ? this.imageFor(b.targetImage.id) : null;

        if (latest) {
          b.targetImage.setVersion(latest.version());
        }
      }
    });

    this.buildListCtrl.setValue(names);

    this._ignoreValuesChange = true;

    this.runTypeCtrl.setValue(this.currentRunSet.useKubernetes ? 'k8s' : 'docker');

    this.showKubernetesCtrl.setValue(this.currentRunSet.useKubernetes);

    this.refreshContainerPortsList();

    this.setAvailableAPIs();
    // this.selectedAPIs.selected = [];

    this.disableAPIControls();

    if (this.currentRunSet) {

      this.selectedAPIs.clear();

      this.currentRunSet.deployments.forEach((s) => {

        if (s.apis.length > 0) {
          this.enableAPIControls();
        }

        s.apis.forEach((api) => {
          this.selectedAPIs.select(this.apiSelection(api.name));
        });

        let apiPortal: Container = this.containerInServiceForType(s, 'apipr');

        if (apiPortal) {
          this.usePortalCtrl.setValue(true);
        }

        let microGateway: Container = this.containerInServiceForType(s, 'apimg');

        if (microGateway) {
          this.useMicrogatewayCtrl.setValue(true);

          if (microGateway.environmentVariable('mcgw_api_gateway_url', this._settings.currentEnvironment)) {
            this.microgatewayTypeCtrl.setValue('env');
          } else {
            this.microgatewayTypeCtrl.setValue('zip');
          }
        }

      });
    }

    this.setEnvFormPropertiesFromMicroServiceRuntime();

    this._ignoreValuesChange = false;
  }

  private setEnvFormPropertiesFromMicroServiceRuntime() {

    this.currentRunSet.deployments.forEach((d) => {
      d.containers.forEach((container) => {

        if (container.build) {

          let cmd: BuildCommand = container.fileForType('properties');

          if (cmd) {
            this.propsCtrl.setValue(cmd.source.replace(/\-/g, ' '));
          }
        }

        let arg: Arg = container.environmentVariable('SAG_IS_CONFIG_PROPERTIES', this._settings.currentEnvironment);

        if (arg) {
          this.envPropsCtrl.setValue(arg.target);
        }

        arg = container.environmentVariable('PERSIST_CONFIGS', this._settings.currentEnvironment);

        if (arg) {
          this.envConfigCtrl.setValue(arg.target);
        }

        arg = container.environmentVariable('HOST_DIR', this._settings.currentEnvironment);

        if (arg) {
          this.envHostDirCtrl.setValue(arg.target);
        }

        arg = container.environmentVariable('SERVICE_NAME', this._settings.currentEnvironment);

        if (arg) {
          this.envServiceDirCtrl.setValue(arg.target);
        }

        arg = container.environmentVariable('PERSIST_LOGS', this._settings.currentEnvironment);

        if (arg) {
          this.envPersistLogsCtrl.setValue(arg.target);
        }

        arg = container.environmentVariable('SAG_IS_AUDIT_STDOUT_LOGGERS', this._settings.currentEnvironment);

        if (arg) {
          this.envPersistOtherLogsCtrl.setValue(arg.target);
        }

        arg = container.environmentVariable('EXTERNALIZE_PACKAGES', this._settings.currentEnvironment);

        if (arg) {
          this.envPackagesCtrl.setValue(arg.target);
        }
      });
    });

    this.refreshContainerEnvList();
  }

  private updateMicroServiceContainerEnvProperties() {

    this.currentRunSet.deployments.forEach((d) => {
      d.containers.forEach((c) => {
        if (c.type == 'msr') {
          this._updateMicroServiceContainerEnvProperties(c);
        }
      });
    });
  }

  private _updateMicroServiceContainerEnvProperties(container: Container) {

    if (this.envPropsCtrl.dirty) {
      this.updateEnvPropsFile(container);
    }

    if (this.envConfigCtrl.dirty) {
      let arg: Arg = container.environmentVariable('PERSIST_CONFIGS', this._settings.currentEnvironment);

      if (arg == null) {
        container.addEnvironmentVariable(new Arg('PERSIST_CONFIGS', this.envConfigCtrl.value, 'Configuration Variables Template'), this._settings.currentEnvironment);
      } else {
        arg.target = this.envConfigCtrl.value;
      }
    }

    if (this.envHostDirCtrl.dirty) {
      let arg: Arg = container.environmentVariable('HOST_DIR', this._settings.currentEnvironment);

      if (arg == null) {
        container.addEnvironmentVariable(new Arg('HOST_DIR', this.envHostDirCtrl.value, 'Host volume mounted directory to use for writing files'), this._settings.currentEnvironment);
      } else {
        arg.target = this.envHostDirCtrl.value;
      }
    }

    if (this.envServiceDirCtrl.dirty) {
      let arg: Arg = container.environmentVariable('SERVICE_NAME', this._settings.currentEnvironment);

      if (arg == null) {
        container.addEnvironmentVariable(new Arg('SERVICE_NAME', this.envServiceDirCtrl.value, 'Sub-directory to be included under host directory'), this._settings.currentEnvironment);
      } else {
        arg.target = this.envServiceDirCtrl.value;
      }
    }

    if (this.envPersistLogsCtrl.dirty) {
      let arg: Arg = container.environmentVariable('PERSIST_LOGS', this._settings.currentEnvironment);

      if (arg == null) {
        container.addEnvironmentVariable(new Arg('PERSIST_LOGS', this.envPersistLogsCtrl.value, 'Write server log to standard out'), this._settings.currentEnvironment);
      } else {
        arg.target = this.envPersistLogsCtrl.value;
      }
    }

    if (this.envPackagesCtrl.dirty) {
      let arg: Arg = container.environmentVariable('EXTERNALIZE_PACKAGES', this._settings.currentEnvironment);

      if (arg == null) {
        container.addEnvironmentVariable(new Arg('EXTERNALIZE_PACKAGES', this.envPackagesCtrl.value, 'External location for packages'), this._settings.currentEnvironment);
      } else {
        arg.target = this.envPackagesCtrl.value;
      }
    }

    if (this.envPersistOtherLogsCtrl.dirty) {
      let arg: Arg = container.environmentVariable('SAG_IS_AUDIT_STDOUT_LOGGERS', this._settings.currentEnvironment);

      if (arg == null) {
        container.addEnvironmentVariable(new Arg('SAG_IS_AUDIT_STDOUT_LOGGERS', this.envPersistOtherLogsCtrl.value, 'Write loggers also to standard out'), this._settings.currentEnvironment);
      } else {
        arg.target = this.envPersistOtherLogsCtrl.value;
      }
    }

    this.refreshContainerEnvList();

    this._save();
  }

  private updateEnvPropsFile(container: Container) {

    let arg: Arg = container.environmentVariable('SAG_IS_CONFIG_PROPERTIES', this._settings.currentEnvironment);

    if (arg == null) {
      container.addEnvironmentVariable(new Arg('SAG_IS_CONFIG_PROPERTIES', this.envPropsCtrl.value, 'Configuration Variables Template'), this._settings.currentEnvironment);
    } else {
      arg.target = this.envPropsCtrl.value;
    }
  }

  private imageForContainerType(containerType: string): DockerImage {

    let apiContainer: Container = null;

    for (let i = 0; i < this.currentRunSet.deployments.length; i++) {

      apiContainer = this.containerInServiceForType(this.currentRunSet.deployments[i], containerType);

      if (apiContainer) {
        break;
      }
    };

    if (apiContainer) {
      return this.imageFor(null, apiContainer.image);
    } else {
      return null;
    }
  }


  private enableAPIControls() {

    this.addedApisControls = true;

    this.apiFormGroup.addControl('useMicrogatewayCtrl', this.useMicrogatewayCtrl);
    this.apiFormGroup.addControl('microgatewayTypeCtrl', this.microgatewayTypeCtrl);
    this.apiFormGroup.addControl('usePortalCtrl', this.usePortalCtrl);
  }

  private disableAPIControls() {

    this.addedApisControls = false;

    this.apiFormGroup.removeControl('gatewayImageCtrl');
    this.apiFormGroup.removeControl('microGatewayImageCtrl');
    this.apiFormGroup.removeControl('useMicrogatewayCtrl');
    this.apiFormGroup.removeControl('microgatewayTypeCtrl');

    this.apiFormGroup.removeControl('usePortalCtrl');
    this.apiFormGroup.removeControl('selectedPortalCtrl');
  }

  private setAvailableAPIs(): APIDefinition[] {

    this.apis = [];
    this.packages = [];

    if (this.currentRunSet && this.currentRunSet.builds) {

      this.selectedImages = [];

      this.currentRunSet.builds.forEach((build) => {

        this.selectedImages.push(build.targetImage.uniqueName());

        if (build.deployments) {

          build.deployments.forEach((d) => {

            d.source.include.forEach((p) => {
              this.packages.push(p);
            });

            d.apis.forEach((a) => {
              a.deployment = build.name;
              this.apis.push(a);
            });
          });
        }
      });
    }

    return this.apis;
  }

  private apiSelection(id: string): APIDefinition {

    var api: APIDefinition = null;

    for (var i = 0; i < this.apis.length; i++) {
      if (this.apis[i].name == id) {
        api = this.apis[i];
        break;
      }
    }

    return api;
  }

  private indexOfTemplate(name): number {

    if (!name || !this.runSets) {
      return -1;
    }

    var found: number = -1;

    for (var i = 0; i < this.runSets.length; i++) {

      if (this.runSets[i] == name) {
        found = i;
        break;
      }
    }

    return found;
  }

  private setContainerForBuild(b: Builder): Deployment {

    let container: Container = this.currentRunSet.containerInDeploymentFor(b.hyphenatedName());

    if (!container) {

      this.currentRunSet.namespace = 'webmethods';

      let service: Deployment = new Deployment(this.currentRunSet.namespace);
      service.name = b.name;
      service.apis = this.selectedAPIs.selected;

      let container: Container = new Container();
      container.name = b.hyphenatedName();

      this._containerTemplates.configureContainerFor(container, b.targetImage, b.deploymentType || 'msr', this._settings.currentEnvironment).subscribe((success) => {
        container.name = b.hyphenatedName();
        container.description = b.name;
        this.updateEnvPropsFile(container);
        this.setAPIEndPointForContainer(service, container);
      });

      service.containers.push(container);
      this.currentRunSet.deployments.push(service);

      return service;
    }
  }

  private setAPIEndPointForContainer(svc: Deployment, c: Container) {

    svc.apis.forEach((a) => {
      a.endPoint = c.name + ':' + c.environmentSettings(this._settings.currentEnvironment).ports[0].internal;
    });
  }

  private setAPIContainer(gatewayImage: DockerImage) {

    let apiService: Deployment = this.serviceFor('API Management');

    if (apiService == null) {
      apiService = new Deployment(this.currentRunSet.namespace);
      apiService.name = 'API Management';

      this.currentRunSet.deployments.unshift(apiService);
    }

    let apiServiceContainer: Container = this.containerInServiceForType(apiService, 'apigw');

    if (apiServiceContainer == null) {

      apiServiceContainer = new Container();
      apiServiceContainer.type = 'apigw';

      this._containerTemplates.configureContainerFor(apiServiceContainer, gatewayImage, 'apigw', this._settings.currentEnvironment).subscribe((success) => {
        apiServiceContainer.image = gatewayImage.tag();

        if (apiServiceContainer.name == null) {
          apiServiceContainer.name = gatewayImage.name();
        }

        apiServiceContainer.description = 'API Gateway';
        apiServiceContainer.active = '' + (gatewayImage.name() != 'EXTERNAL');
      });

      apiService.containers.unshift(apiServiceContainer); //. push to top, must be started before api implementation
    }

    this.currentRunSet.builds.forEach((b) => {

      let service: Deployment = this.serviceFor(b.name);

      if (service != null) {
        let msrContainer: Container = this.containerInServiceForType(service, 'msr');
        if (msrContainer != null) {
          this.setMicroServicePropertiesForAPIGatway(msrContainer, apiServiceContainer);
        }
      }
    });
  }

  private setMicroServicePropertiesForAPIGatway(msrContainer: Container, apiServiceContainer: Container) {

    msrContainer.addEnvironmentVariable(new Arg('api_gateway_url', 'http://' + apiServiceContainer.name + ':' + apiServiceContainer.environmentSettings(this._settings.currentEnvironment).ports[0].internal, 'API Gateway URL'), this._settings.currentEnvironment);
    msrContainer.addEnvironmentVariable(new Arg('api_gateway_user', 'Administrator', 'API Gateway User'), this._settings.currentEnvironment);
    msrContainer.addEnvironmentVariable(new Arg('api_gateway_password', 'manage', 'API Gateway Password'), this._settings.currentEnvironment);

    msrContainer.addEnvironmentVariable(new Arg('api_gateway_allow_update', 'false', 'Defines whether latest API definition should replace any already uploaded API'), this._settings.currentEnvironment);
    msrContainer.addEnvironmentVariable(new Arg('api_gateway_default_maturity', 'beta', 'Sets the maturity label of the uploaded API'), this._settings.currentEnvironment);
    msrContainer.addEnvironmentVariable(new Arg('api_gateway_default_grouping', '', 'Assigns the API to specified group'), this._settings.currentEnvironment);
    msrContainer.addEnvironmentVariable(new Arg('api_gateway_default_version', '', 'Default version to be applied to any uploaded APIs'), this._settings.currentEnvironment);
    msrContainer.addEnvironmentVariable(new Arg('api_gateway_default_app', '', 'Default application to be assigned to any uploaded APIs (Will be created if doesn\'t exist)'), this._settings.currentEnvironment);
  }

  private setMicrogatewayContainer(microGatewayImage: DockerImage, type: string) {

    this.currentRunSet.deployments.forEach((d) => {

      let container: Container;

      if ((container = d.containerForType('msr')) != null) {
        this._setMicrogatewayContainer(microGatewayImage, d, type, container);
      }
    });
  }

  private _setMicrogatewayContainer(microGatewayImage: DockerImage, deploymentLayer: Deployment, type: string, microServiceContainer: Container) {

    let microContainer: Container = this.containerInServiceForType(deploymentLayer, 'apimg');
    let selectedAPIS: string = this.containerAPIs();

    if (microContainer == null) {

      microContainer = new Container();
      microContainer.description = 'Micro Gateway';
      microServiceContainer.type = 'apimg';
    }

    microContainer.name = microServiceContainer.name + '-gateway';

    if (type == 'env') {

      this._containerTemplates.configureContainerFor(microContainer, microGatewayImage, 'apimg', this._settings.currentEnvironment).subscribe((success) => {

        microContainer.environmentSettings(this._settings.currentEnvironment).env.push(new Arg('mcgw_downloads_apis', selectedAPIS, 'comma separated list of API\'s to be managed by micro gateway'));

        let arg: Arg = microContainer.environmentVariable('api_server_url', this._settings.currentEnvironment);

        if (arg) {
          arg.target.replace('wm-msr', microServiceContainer.name);
        }

        console.log('arg ' + arg.target);

      });
    } else {
      this._containerTemplates.configureContainerFor(microContainer, microGatewayImage, 'apimg-standalone', this._settings.currentEnvironment).subscribe((success) => {

      });
    }

    deploymentLayer.containers.push(microContainer);

    let i = ContainerTemplates.indexOfAttribute(microContainer, 'api_url', this._settings.currentEnvironment);

    if (i != -1) {
      let container: Container = this.containerInServiceForType(deploymentLayer, 'MicroService Runtime');
      microContainer.environmentSettings(this._settings.currentEnvironment).env[i].target = 'http://' + container.name + ':' + container.environmentSettings(this._settings.currentEnvironment).ports[0].internal;
    }

    microContainer.image = microGatewayImage.tag();
  }

  private removeMicrogatewayContainer() {

    this.currentRunSet.deployments.forEach((d) => {

      if (d.containerForType('msr')) {

        let index: number = this.containerIndexInServiceFor(d, 'apimg');

        if (index != -1) {
          d.containers.splice(index, 1);
          this._save();
        }
      }
    });
  }

  private setPortalContainer(image: DockerImage) {

    let apiService: Deployment = this.serviceFor('API Management');

    if (apiService == null) {
      apiService = new Deployment(this.currentRunSet.namespace);
      apiService.name = 'API Management';

      this.currentRunSet.deployments.push(apiService);
    }

    let apiServiceContainer: Container = this.containerInServiceForType(apiService, 'apipr');

    if (apiServiceContainer == null) {

      apiServiceContainer = new Container();
      apiServiceContainer.type = 'apipr';

      this._containerTemplates.configureContainerFor(apiServiceContainer, image, 'apipr', this._settings.currentEnvironment).subscribe((success) => {

      });

      apiService.containers.push(apiServiceContainer);
    }

    apiServiceContainer.image = image.tag();
    apiServiceContainer.active = '' + (image.name() != 'EXTERNAL');
  }

  private removePortalContainer() {

    let service: Deployment = this.serviceFor('API Management');

    if (service) {
      let index: number = this.containerIndexInServiceFor(service, 'apipr');

      if (index != -1) {
        service.containers.splice(index, 1);
        this._save();
      }
    }
  }

  private containerAPIs(): string {

    let apis: string = '';

    this.currentRunSet.deployments.forEach((s) => {
      s.apis.forEach((a) => {
        if (apis.length > 0) {
          apis = apis + ',' + a.name;
        } else {
          apis = a.name;
        }
      });
    });

    return apis;
  }

  private serviceFor(id: string): Deployment {

    if (this.currentRunSet == null) {
      return;
    }

    let found: Deployment = null;

    for (var i = 0; i < this.currentRunSet.deployments.length; i++) {

      if (this.currentRunSet.deployments[i].name == id) {
        found = this.currentRunSet.deployments[i];
        break;
      }
    }

    return found;
  }

  private containerInServiceForType(service: Deployment, type: string): Container {

    let found: Container = null;

    for (var i = 0; i < service.containers.length; i++) {

      if (service.containers[i].type == type) {
        found = service.containers[i];
        break;
      }
    }

    return found;
  }

  private containerInServiceFor(service: Deployment, id: string, tag?: string): Container {

    let found: Container = null;

    for (var i = 0; i < service.containers.length; i++) {

      if (service.containers[i].name == id ||
        (tag && service.containers[i].image.indexOf(tag) != -1)) {
        found = service.containers[i];
        break;
      }
    }

    return found;
  }

  private containerIndexInServiceFor(service: Deployment, type: string): number {

    let found: number = -1;

    for (var i = 0; i < service.containers.length; i++) {

      if (service.containers[i].type == type) {
        found = i;
        break;
      }
    }

    return found;
  }

  private imageFor(id: string, tag?: string): DockerImage {

    let found: DockerImage = null;

    for (var i = 0; i < this.customImages.length; i++) {

      if (this.customImages[i].name() == id ||
        (tag && tag.endsWith(this.customImages[i].tag()))) {
        found = this.customImages[i];
        break;
      }
    }

    if (!found) {

      for (var i = 0; i < this.baseImages.length; i++) {

        if (this.baseImages[i].name() == id ||
          (tag && tag.endsWith(this.baseImages[i].tag()))) {
          found = this.baseImages[i];
          break;
        }
      }
    }

    return found;
  }

  public colorForContainer(container: Container) {

    if (container.active == 'true') {
      return 'primary';
    } else if (container.hostname) {
      return 'accent';
    } else {
      return 'gray';
    }
  }

  public editContainer(container: Container, event: any) {

    let x = event.pageX;
    let y = event.pageY;

    let dialogRef = this._dialog.open(EditContainerComponent, {
      data: {container: container, formBuilder: this._formBuilder},
      width: '360px',
      height: '360px',
    });

    console.log("left: '${x}px', top: '${y}px'");

    dialogRef.updatePosition({left: x + "px", top: y + "px"});

    dialogRef.afterClosed().subscribe(container => {
      console.log(`Dialog result: ${container}`);

      this._save();
    });
  }

  private refreshContainerPortsList() {

    this.currentRunSet.deployments.forEach((s) => {
      s.containers.forEach((c) => {
        c.environmentSettings(this._settings.currentEnvironment).ports = Object.assign([], c.environmentSettings(this._settings.currentEnvironment).ports);
      });
    });
  }

  private refreshContainerEnvList() {

    this.currentRunSet.deployments.forEach((s) => {
      s.containers.forEach((c) => {
        c.environmentSettings(this._settings.currentEnvironment).env = Object.assign([], c.environmentSettings(this._settings.currentEnvironment).env);
      });
    });
  }
}
