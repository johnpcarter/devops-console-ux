import {Component, EventEmitter, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {DomSanitizer} from '@angular/platform-browser';
import {Router} from '@angular/router';

import {MatDialog} from '@angular/material/dialog';
import {Container, RunSet} from '../models/project';
import {ConfigurationService} from '../services/configuration.service';
import {DockerService} from '../services/docker.service';
import {TestTraceService} from '../services/test-trace.service';

import {Settings} from '../settings';

import * as $ from 'jquery';
import {ShapeCoords, ShapeLayer} from '../graph/shape-layer';
import {LayoutLink} from '../graph/layout-link';
import {GraphRenderer} from '../graph/graph-renderer';
import {ShapeType} from '../graph/layout-rule';
import {ContainerLayoutTemplates} from '../support/container.layout';

@Component({
  selector: 'runtime-containers-graph',
  templateUrl: '../templates/runtime-containers-graph.html',
  styleUrls: ['../templates/runtime-containers.css']
})

export class RuntimeContainersGraphComponent implements OnInit, OnDestroy {

  @Input()
  public containers: Container[];

  @Input()
  public selectedDeployment: RunSet;

  @Input()
  public useFullWidth: boolean = true;

  @Output()
  public stopContainerEvent: EventEmitter<Container> = new EventEmitter();

  public deploymentLayers: ShapeLayer[] = [];
  public links: LayoutLink[] = [];

  private _host: string;
  private _context: any;


	public constructor(private _router: Router, private _settings: Settings, private _configService: ConfigurationService, private _dialog: MatDialog,
		private _dockerService: DockerService, private _testMgr: TestTraceService, private _sanitizer: DomSanitizer) {

	}

  public ngOnInit() {

    this._settings.values().subscribe((s) => {
      if (s.dockerHost)
        this._host = s.dockerHost.substring(0, s.dockerHost.indexOf(":"));
      else
        this._host = "localhost";

      if (this._host == 'host.docker.internal')
        this._host = 'localhost';

      this._settings.setCurrentPage('deploy');
    });

    let canvas = document.getElementById('runtime-container-graph');
    this._context = (<any> canvas).getContext('2d');
    //this._context.scale(2, 2);

    this.deploymentSelectionChanged(true);
  }

  public ngOnChanges() {

    this.deploymentSelectionChanged();
  }

  public ngOnDestroy() {

  }

  public deploymentSelectionChanged(onInit?: boolean) {

	  this.deploymentLayers = [];

	  if (this.containers.length == 0 && !this.selectedDeployment)
	    return;

	  this.render();
  }

  public render() {

    if (this.selectedDeployment) {

      let layout = ContainerLayoutTemplates.layoutDeployment(this.selectedDeployment);
      let r = new GraphRenderer(this.selectedDeployment, this._context, layout.layoutRule, layout.rules);

      r.render(this.selectedDeployment.deployments, this.availableWidth());
      r.setOrigin(new ShapeCoords(GraphRenderer.MARGINX, GraphRenderer.MARGINY), 0, this.availableWidth());

      if (this._context) {
        this._context.clearRect(0, 0, this.availableWidth(), r.height);
      }
      this.deploymentLayers.push(r);

    } else {
      let layout = ContainerLayoutTemplates.layoutContainers(this.containers);

      let l = new GraphRenderer("All Containers", this._context, layout.layoutRule, layout.rules);
      l.render(this.containers, this.availableWidth());
      l.setOrigin(new ShapeCoords(GraphRenderer.MARGINX, GraphRenderer.MARGINY), 1, this.availableWidth());

      this.deploymentLayers.push(l);
    }

    this.connectContainers();
  }

  public connectContainers() {

    this.deploymentLayers.forEach((d) => {
      (<GraphRenderer> d).shapes.forEach((c) => {
        if ((<ContainerShapeLayer> c).container.type == 'apigw') {
          this.buildLinksFromAPIGateway(<GraphRenderer> d, <ContainerShapeLayer> c)
        } else if ((<ContainerShapeLayer> c).container.type == 'apimg') {
          this.buildLinksFromMicroGateway(<GraphRenderer> d, <ContainerShapeLayer> c);
        } else if ((<ContainerShapeLayer> c).container.type == 'msr') {

        } else {

        }
      });
    });
  }

  private buildLinksFromMicroGateway(deployment: GraphRenderer, containerShape: ContainerShapeLayer) {

    this.deploymentLayers.forEach((d) => {
      (<GraphRenderer> d).shapes.forEach((c) => {
        let cc: ContainerShapeLayer = <ContainerShapeLayer> c;

        if (cc.container.type == 'msr') {

          let l = new LayoutLink("invokes", deployment, containerShape, <GraphRenderer> d, cc);
          this.links.push(l);
        } else if (cc.container.type == 'apigw') {
          // check if our microgateway is hooked up

          if (containerShape.container.environmentSettings().environmentVariable('mcgw_api_gateway_url').target.indexOf(cc.container.name) != -1) {
            let l = new LayoutLink("policies & monitoring", deployment, containerShape, <GraphRenderer> d, cc);
            this.links.push(l);
          }
        }
      });
    });
  }

  private buildLinksFromAPIGateway(deployment: GraphRenderer, containerShape: ContainerShapeLayer) {

	  let elkEndPoint = containerShape.container.environmentSettings().environmentVariable('apigw_elasticsearch_hosts').target;

	  if (elkEndPoint != null) {
      this.deploymentLayers.forEach((d) => {
        (<GraphRenderer>d).shapes.forEach((c) => {
          let cc: ContainerShapeLayer = <ContainerShapeLayer>c;

          if (elkEndPoint.indexOf(cc.container.name) != -1) {
            let l = new LayoutLink("storage", deployment, containerShape, <GraphRenderer> d, cc);
            this.links.push(l);
          }
        });
      });
    }
  }

  private availableWidth(): number {
    return $('#runtime-containers-page').width() - (GraphRenderer.MARGINX*2);
  }
}

export class ContainerShapeLayer extends ShapeLayer {

  public container: Container;

  constructor(container: Container, context: any, type?: ShapeType, coords?: ShapeCoords) {

    super(container.type == "apimg" ? "Micro Gateway" : container.description, context, type, coords);

    this.container = container;
    this.subTitle = container.type == "msr" ? container.name : null;
    this.backgroundColor = this.isAlive() ? "lightblue" : 'lightgrey';
  }

  public isAlive() {

    return this.container.state && this.container.state == 'running';
  }
}
