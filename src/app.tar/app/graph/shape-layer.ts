import {ShapeType} from './layout-rule';

export class ShapeSize {
  constructor(public width: number, public height: number) {

  }
}

export class ShapeCoords {

  public titlex: number;
  public titley: number;
  public subTitlex: number;

  constructor(public x: number, public y: number, public width: number = ShapeLayer.DEFAULT_WIDTH, public height: number = ShapeLayer.DEFAULT_HEIGHT) {

  }
}

export class ShapeLayer {

  public static DEFAULT_WIDTH: number = 75;
  public static DEFAULT_HEIGHT: number = 75;

  public referencedObject: any;
  public title: string;
  public titleColor: string;
  public subTitle: string;
  public subTitleColor: string;

  public x: number = 0;
  public y: number = 0;

  public width: number = ShapeLayer.DEFAULT_WIDTH;
  public height: number = ShapeLayer.DEFAULT_HEIGHT;

  public type: ShapeType = ShapeType.rect;

  public backgroundColor: string;

  public shapes: ShapeLayer[] = [];

  protected _context: any;

  public constructor(ref: any, context: any, type: ShapeType, coords?: ShapeCoords) {

    this.referencedObject = ref;

    if (typeof(ref) == 'string')
      this.title = ref;
    else
      this.title = ref.title;

    this._context = context;
    this.backgroundColor = "gray";
    this.type = type;

    if (coords) {

      if (coords.width)
        this.width = coords.width;

      if (coords.height)
        this.height = coords.height;

      if (this.type == ShapeType.rect) {
        this.x = coords.x;
        this.y = coords.y;
      } else {
        this.x = coords.x - (this.width/2);
        this.y = coords.y = (this.height/2)
      }
    }
  }

  public isRect(): boolean {
    return this.type == ShapeType.rect;
  }

  public isEllipse(): boolean {
    return this.type == ShapeType.ellipse;
  }

  public coords(parent?: ShapeLayer): ShapeCoords {

    let coords;

    let width = this.width;// + DeploymentShapeLayer.MARGINX*3;

    let w: number = 100;
    let s: number = 100;

    if (this._context) {
      w = this._context.measureText(this.title).width / 2;
      s = this._context.measureText(this.subTitle).width / 2;
    }

    let tx = this.x - w;
    let ts = this.x - s;
    let ty = this.y + this.height;

    if (this.type == ShapeType.rect) {

      tx = this.x + ((width/2) - w);
      ts = this.x + ((width/2) - s);
      ty += 25;
    }

    if (parent) {
      coords = new ShapeCoords(parent.x + this.x, parent.y + this.y);
      coords.titlex = parent.x + tx;
      coords.titley = parent.y + ty;
      coords.subTitlex = parent.x + ts;
    } else {
      coords = new ShapeCoords(this.x, this.y);
      coords.titlex = tx;
      coords.titley = ty;
      coords.subTitlex = ts;
    }

    coords.width = this.width
    coords.height = this.height
    
    return coords;
  }
}
