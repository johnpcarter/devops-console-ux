import {Container} from '../models/project';
import {ContainerShapeLayer} from '../components/runtime-containers-graph.component';
import {ContainerLayoutTemplates} from '../support/container.layout';
import {ShapeCoords, ShapeLayer, ShapeSize} from './shape-layer';
import {LayoutRule, ShapeAlignment, ShapeType, ShapeWidthType} from './layout-rule';

export class GraphRenderer extends ShapeLayer {

  public static TITLE_MARGIN: number = 50;
  public static MARGINX: number = 100;
  public static MARGINY: number = 20;

  private layoutRule: LayoutRule;
  private layoutRules: LayoutRule[] = [];

  constructor(ref: any, context: any, layoutRule: LayoutRule, layoutRules: LayoutRule[]) {
    super(ref, context, ShapeType.rect);

    this.layoutRule = layoutRule;
    this.layoutRules = layoutRules;
    this.backgroundColor = "lightgray";
  }

  public render(objects: any[], availableWidth: number): ShapeSize {

    let width: number = this.layoutRule.useWidth == ShapeWidthType.half ? (availableWidth - (GraphRenderer.MARGINX*2) / 2) : availableWidth;
    let rules = this.layoutRules
    let ypos: number = GraphRenderer.MARGINY

    while(rules.length > 0) {
      rules = this.renderNextRow(rules, objects, ypos, width);
    }

    let maxY: number = 0;
    let maxX: number = 0;

    this.shapes.forEach((s) => {
      if (s.y + s.height > maxY) {
        maxY = s.y + s.height;
      }
      if (s.x + s.width > maxX) {
        maxX = s.x + s.width;
      }
    });

    this.width = this.layoutRule.useWidth == ShapeWidthType.dynamic ?  maxX + GraphRenderer.MARGINX : this.layoutRule.useWidth == ShapeWidthType.half ? availableWidth / 2 : availableWidth - GraphRenderer.MARGINX;
    this.height = maxY + GraphRenderer.TITLE_MARGIN;

    return new ShapeSize(this.width, this.height);
  }

  public renderNextRow(rules: LayoutRule[], objects: any[], ypos: number, availableWidth): LayoutRule[] {

    let items = 0

    // first loop, determine how many items can we fit in row and the width.

    let rowWidth = 0

    for (let i = 0; i < rules.length; i++) {

      if (rules[i].startOnNewRow) {
        break
      }

      rowWidth += rules[i].width + GraphRenderer.MARGINX;

      if (rowWidth < availableWidth) {
        items += 1
      }
      else {
        break
      }
    }

    // determine start point

    let xpos = GraphRenderer.MARGINX;

    if (this.layoutRule.alignment == ShapeAlignment.center) {
      xpos = availableWidth / 2 - (rowWidth/2)
    } else {
      xpos = availableWidth - rowWidth
    }

    // now render shapes

    for (let i = 0; i < rules.length; i++) {

      let obj = this.objectForRef(rules[i].id, rules[i].name, objects);
      this.renderObject(obj, xpos, ypos, rules[i]);
    }

    if (items < rules.length) {
      return rules.slice(items + 1);
    } else {
      return [];
    }
  }

  private renderObject(object: any, x: number, y: number, l: LayoutRule) {

    let coords: ShapeCoords = new ShapeCoords(x, y, l.width, l.height);
    let shape;

    if (object instanceof Container) {
      shape = new ContainerShapeLayer(object, this._context, l.type, coords);
      this.shapes.push(shape);
    } else {

      if (this.referencedObject.deployments) {
        shape = new GraphRenderer(object, this._context, l, ContainerLayoutTemplates.layoutContainers(this.referencedObject.deployments).rules);
        shape.render(this.referencedObject.deployments, l.width)
      } else if (this.referencedObject.containers) {
        shape = new GraphRenderer(object, this._context, l, ContainerLayoutTemplates.layoutContainers(this.referencedObject.containers).rules);
        shape.render(this.referencedObject.containers, l)
      }

      shape.setOrigin(coords);
      this.shapes.push(shape);
    }
  }

  private objectForRef(id: string, name: string, containers: any[]): any {

    let found: Container = null;

    for (let i=0; i<containers.length;i++) {
      if (containers[i].id == id) {
        found = containers[i];
        break;
      }
    }

    // try name

    if (found == null) {
      for (let i=0; i<containers.length;i++) {
        if (containers[i].name == name) {
          found = containers[i];
          break;
        }
      }
    }

    return found;
  }
}
