
export class BuildImage {
  public sourceImage;
  public sourceVersion;
  public targetImage;
}